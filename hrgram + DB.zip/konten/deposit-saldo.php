<div class="alert alert-info text-center">
	Maaf, Fitur ini sedang perbaikan, Silahkan Deposit Manual Via Admin Dibawah
</div>
        <div class="col-md-6 col-md-offset-3">
            <div class="panel panel-info text-center">
                <div class="panel-heading">Kontak Admin</div>
                <div class="panel-body">
                    <center>
                        <p><b>WhatsApp: </b>0821-3377-9498</p>
                        <p><b>ID Line : </b>mhafizhrh</p>
                        <p><b>Facebook :</b> <a href="http://facebook.com/hafizh.rh" target="blank">Add Me+</a></p>
                    </center>
                </div>
            </div>
        </div>